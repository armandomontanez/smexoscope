 ****************************************************************************
 * Copyright (C) 2003 Bram de Jong
 * 
 * This program is free software: you can redistribute it and/or modify 
 * it under the terms of the GNU General Public License as published by	
 * the Free Software Foundation, either version 3 of the License, or 
 * (at your option) any later version. 
 * 
 * This program is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License 
 * along with this program.  If not, see <http://www.gnu.org/licenses/>. 
 ****************************************************************************

Bram @ Smartelectronix presents :: The S(m)exoscope
---------------------------------------------------


bram @ smartelectronix.com	:: Code & Conccept
sean @ deadskinboy.com		:: GUI Design
kerrydan			:: Documentation
marc @ smartelectronix.com	:: Mac port
armando				:: Multiplatform JUCE port


Smexoscope is not an effect, nor is it a synthesiser, don't
expect it to generate noise: it's a visualisation only plugin!

Usefull for looking at waveforms and very usefull for developers.

For more info, see the splendid documentation by Kerrydan.

have fun,


 - bram, sean, kyle, armando



revision history
----------------
20161106
* fixed line rendering gaps
* rebuilt for release compatibility and optimization
* included build for 64-bit Windows

20160902
* ported to JUCE framework
* refresh rate increased to 30fps
* Mouse crosshair black instead of inverted

20040403
* DC-Killer now defaults to OFF [Ross Bencina]
* changed the way the trigger works ("<" to "<=" etc...) [Ross Bencina]
* XY-cross with value readouts on left-click

20031203 :: first release