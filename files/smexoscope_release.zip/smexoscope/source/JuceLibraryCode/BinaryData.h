/* =========================================================================================

   This is an auto-generated file: Any edits you make may be overwritten!

*/

#ifndef BINARYDATA_H_79162356_INCLUDED
#define BINARYDATA_H_79162356_INCLUDED

namespace BinaryData
{
    extern const char*   blue_knob1_4_png;
    const int            blue_knob1_4_pngSize = 102873;

    extern const char*   body_png;
    const int            body_pngSize = 164693;

    extern const char*   free_etc_png;
    const int            free_etc_pngSize = 896;

    extern const char*   heads_png;
    const int            heads_pngSize = 3522;

    extern const char*   lefr_right_png;
    const int            lefr_right_pngSize = 881;

    extern const char*   off_on_png;
    const int            off_on_pngSize = 845;

    extern const char*   readout_png;
    const int            readout_pngSize = 6253;

    extern const char*   slider_new_png;
    const int            slider_new_pngSize = 229;

    // Points to the start of a list of resource names.
    extern const char* namedResourceList[];

    // Number of elements in the namedResourceList array.
    const int namedResourceListSize = 8;

    // If you provide the name of one of the binary resource variables above, this function will
    // return the corresponding data and its size (or a null pointer if the name isn't found).
    const char* getNamedResource (const char* resourceNameUTF8, int& dataSizeInBytes) throw();
}

#endif
